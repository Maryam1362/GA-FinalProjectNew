function AppCtrl(){
	console.log("Hello world from Controller");
}